﻿using Bacaling_FinalProject_OOP.ViewModel;
using Bacaling_FinalProject_OOP.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Bacaling_FinalProject_OOP.View
{
    /// <summary>
    /// Interaction logic for CustomerManagement.xaml
    /// </summary>
    public partial class CustomerManagement : Window
    {
        public CustomerManagement()
        {
            InitializeComponent();
            DataContext = new CustomerManagementViewModel();
        }
        private void FilterTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            UserList.Items.Filter = FilterMethod;
        }
        private bool FilterMethod(object obj)
        {
            var user = (Customer)obj;
           
            return user.Name.Contains(FilterTextBox.Text, StringComparison.OrdinalIgnoreCase) || user.ContactNumber.Contains(FilterTextBox.Text, StringComparison.OrdinalIgnoreCase);
            
        }
       
    }
}
