﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Bacaling_FinalProject_OOP.Model;
using Bacaling_FinalProject_OOP.ViewModel;

namespace Bacaling_FinalProject_OOP.View
{
    /// <summary>
    /// Interaction logic for CustomBuild.xaml
    /// </summary>
    public partial class CustomBuild : Window
    {
        public CustomBuild()
        {
            InitializeComponent();
            CustomBuildViewModel viewModel = new CustomBuildViewModel();
            DataContext = viewModel;
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            InventoryList.Items.Filter = FilterMethod;
        }
        private bool FilterMethod(object obj)
        {
            var cat = obj as Category?;
            return cat.ToString().Contains(SearchBar.Text, StringComparison.OrdinalIgnoreCase);
        }
        private bool Filter(object obj)
        {

            PcComponent com = (PcComponent)obj;
            return com.Category.ToString().Contains(SearchBar.Text, StringComparison.OrdinalIgnoreCase) || com.Name.Contains(SearchBar.Text, StringComparison.OrdinalIgnoreCase) || com.Brand.Contains(SearchBar.Text, StringComparison.OrdinalIgnoreCase) || com.Model.Contains(SearchBar.Text, StringComparison.OrdinalIgnoreCase);
        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {
            InventoryList.Items.Filter = Filter;
        }
    }
}
