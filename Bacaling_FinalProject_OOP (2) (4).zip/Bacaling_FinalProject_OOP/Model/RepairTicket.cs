﻿using Bacaling_FinalProject_OOP.Command;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Bacaling_FinalProject_OOP.Model
{
    public enum Status
    {
        Ongoing, Open, Completed
    }
    public enum Diagnosis
    {
        Hardware, Software
    }
    public class RepairTicket: NotifyPropertyChanged
    {
        public string Id { get; set; }
        public Customer Customer { get; set; }
        public string Description { get; set; }
        public Diagnosis Diagnosis { get; set; }
        private Status? _status;
        public Status? Status 
        {
            get { return _status; }
            set 
            { 
                _status = value;
                OnPropertyChanged(nameof(Status));
            }
        }
        public string GenerateID()
        {
            Random random = new Random();
            string id = "";
            for (int i = 0; i < 10; i++)
            {
                int generate = random.Next(0, 9);
                id += generate;
            }
            return id.ToString();
        }
        public RepairTicket(Customer customer, string description, Diagnosis diagnosis, Status? status)
        {
            Id = GenerateID();
            Customer = customer;
            Description = description;
            Diagnosis = diagnosis;
            Status = status;
        }
    }
}
