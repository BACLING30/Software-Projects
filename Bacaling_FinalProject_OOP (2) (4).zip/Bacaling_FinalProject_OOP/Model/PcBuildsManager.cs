﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bacaling_FinalProject_OOP.Model
{
    public class PcBuildsManager
    {
        public static ObservableCollection<PcBuild> Futurebuilds { get; set; } = new ObservableCollection<PcBuild>();

        public static ObservableCollection<PcBuild> GetBuilds()
        {
            return Futurebuilds;
        }
        public static void AddPcBuild(PcBuild build)
        {
            Futurebuilds.Add(build);
        }
    }
}
