﻿using Bacaling_FinalProject_OOP.Command;
using Bacaling_FinalProject_OOP.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bacaling_FinalProject_OOP.Model
{
    public enum Category
    {
        CPU, GPU, RAM, PSU, SSD,  MotherBoard
    }
    public class PcComponent:NotifyPropertyChanged
    {
        private string? _id;
        private string? _name;
        private string? _brand;
        private string? _model;
        private int _price;
        private Category? _category;
        private int? _quantity;
        private int _secondQuantity;
        private int _total;
        
        public string? Id 
        { get { return _id; }
            set
            {
                _id = value; 
                OnPropertyChanged(nameof(Id));
            }
        }
        public string? Name 
        { get { return _name; }
            set
            {
                _name = value; 
                OnPropertyChanged(nameof(Name));
            }
        }
        public string? Brand 
        { get { return _brand; }
            set
            {
                _brand = value; 
                OnPropertyChanged(nameof(Brand));
            }
        }
        public string? Model 
        { get { return _model; }
            set
            {
                _model = value; 
                OnPropertyChanged(nameof(Model));
            }
        }
        public int Price 
        { get { return _price; }
            set
            {
                _price = value; 
                OnPropertyChanged(nameof(Price));
            }
        }
        public Category? Category 
        { get { return _category; }
            set
            {
                _category = value; 
                OnPropertyChanged(nameof(Category));
            }
        }
       public int? Quantity
        {
            get { return _quantity;}
            set 
            { 
                _quantity = value;
                OnPropertyChanged(nameof(Quantity));
            }
        }
        public int SecondQuantity
        {
            get { return _secondQuantity;}
            set 
            {
                _secondQuantity = value;
                OnPropertyChanged();
            }
        }
        public PcComponent(string id, string name, string brand, string model, int price, Category category, int quantity)
        {
            Id = id;
            Name = name;
            Brand = brand;
            Model = model;
            Price = price;
            Category = category;
            Quantity = quantity;
        }
    }
}
