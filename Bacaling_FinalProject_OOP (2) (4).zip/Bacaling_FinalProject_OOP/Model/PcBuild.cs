﻿using Bacaling_FinalProject_OOP.Command;
using Bacaling_FinalProject_OOP.ViewModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bacaling_FinalProject_OOP.Model
{
    public class PcBuild : NotifyPropertyChanged
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public ObservableCollection<PcComponent> Builds{ get; set; } = new ObservableCollection<PcComponent>();
        public int TotalPrice { get; set; }

        public PcBuild(string id, ObservableCollection<PcComponent> builds)
        {
            Id = id;
            Builds = builds;
        }
        
    }
}
