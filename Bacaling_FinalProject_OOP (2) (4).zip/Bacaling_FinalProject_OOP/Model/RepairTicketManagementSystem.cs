﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bacaling_FinalProject_OOP.Model
{
    public class RepairTicketManagementSystem
    {
        public static ObservableCollection<Diagnosis> DiagnoseList { get; set; } = new ObservableCollection<Diagnosis>()
        {
            Diagnosis.Hardware, Diagnosis.Software
        };
        public static ObservableCollection<Status> StatusList { get; set; } = new ObservableCollection<Status>()
        {
            Status.Completed, Status.Ongoing, Status.Open
        };

        public static ObservableCollection<RepairTicket> DatabaseRepairTickets = new ObservableCollection<RepairTicket>()
        {
            new RepairTicket(GenerateCustomer(),"Burning smell", GenerateDiagnosis(), GenerateStatus()),
            new RepairTicket(GenerateCustomer(),"Clicking sound inside", GenerateDiagnosis(), GenerateStatus()),
            new RepairTicket(GenerateCustomer(), "Frequent crashing of apps", GenerateDiagnosis(), GenerateStatus())
        };
        public static ObservableCollection<RepairTicket> GetTickets()
        {
            return DatabaseRepairTickets;
        }
        public static Status GenerateStatus()
        {
            Random random = new Random();
            int i = random.Next(0, StatusList.Count);
            return StatusList[i];
        }
        public static Diagnosis GenerateDiagnosis()
        {
            Random random = new Random();
            int i = random.Next(0, DiagnoseList.Count);
            return DiagnoseList[i];
        }
        public static Customer GenerateCustomer()
        {
            Random random = new Random();
            int i = random.Next(0, CustomerManagementSystem.DataBaseCustomer.Count);
            return CustomerManagementSystem.DataBaseCustomer[i];
        }
        public static void AddTicket(RepairTicket rep)
        {
            DatabaseRepairTickets.Add(rep);
        }
        public static void EditStatus(RepairTicket rep, Status? stat)
        {
            rep.Status = stat;
        }
    }
}
