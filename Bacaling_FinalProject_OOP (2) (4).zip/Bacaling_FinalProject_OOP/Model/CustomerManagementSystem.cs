﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Bacaling_FinalProject_OOP.Model
{
    public class CustomerManagementSystem
    {
        public static ObservableCollection<Customer> DataBaseCustomer { get; set; } = new ObservableCollection<Customer>()
        {
            new Customer("Matthew", "09427890987"),
            new Customer("Alfonso", "09238043294"),
            new Customer("Simon", "203574453253"),
            new Customer("Keen", "87490324232"),
            new Customer("Reshan", "9509643242"),
            new Customer("Fergievon", "5635437548568"),
            new Customer("Chris", "9876935839"),
            new Customer("Japhet", "94765802345"),
            new Customer("John Branzuela", "94765802345"),
            new Customer("Edicio Faller", "94765802345")
        };

        public static ObservableCollection<Customer> GetCustomers()
        {
            return DataBaseCustomer;
        }
        public static void AddCustomer(Customer cus)
        {
            DataBaseCustomer.Add(cus);
        }
        public static void RemoveCustomer(Customer cus)
        {
            DataBaseCustomer.Remove(cus);
        }
        public static void EditCustomer(Customer cus, string? id, string? name, string? contactNumber)
        {
            cus.Id = id;
            cus.Name = name;
            cus.ContactNumber = contactNumber;
        }
    }
}
