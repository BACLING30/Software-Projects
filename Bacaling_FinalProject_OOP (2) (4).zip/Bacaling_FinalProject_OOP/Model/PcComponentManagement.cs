﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Security.RightsManagement;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Bacaling_FinalProject_OOP.Model
{
    public class PCComponentManagement
    {
        public static ObservableCollection<PcComponent> DataBaseComponents { get; set; } = new ObservableCollection<PcComponent>()
        {
            new PcComponent(GenerateID(),"I5","ADDU","GF63 8RC", 5000, Category.RAM, 5),
            new PcComponent(GenerateID(),"RTX 4080","ADDU","GF63 8RC", 5000, Category.GPU, 12),
            new PcComponent(GenerateID(),"I3","ADMU","GF64 8RC", 3000, Category.RAM, 9),
            new PcComponent(GenerateID(),"NVIDIA","ADMU","GF64 8RC", 3000, Category.PSU, 1)
        };
        public static ObservableCollection<PcComponent> GetComponents()
        {
            return DataBaseComponents;
        }
        public static string GenerateID()
        {
            Random random = new Random();
            string id = "";
            for (int i = 0; i < 10; i++)
            {
                int generate = random.Next(0, 9);
                id += generate;
            }
            return id;
        }
        public static void AddPart(PcComponent com)
        {
            DataBaseComponents.Add(com);
        }
        public static void RemovePart(PcComponent com)
        {
            DataBaseComponents.Remove(com);
        } 
        public static void EditPart(PcComponent com, string? name, string? brand, string? model, string? id, int price, Category? category, int? quantity)
        {
            com.Name = name;
            com.Brand = brand;
            com.Model = model;
            com.Id = id;
            com.Price = price;
            com.Category= category;
            com.Quantity = quantity;
        }
    }
}
