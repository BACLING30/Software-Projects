﻿using Bacaling_FinalProject_OOP.Command;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bacaling_FinalProject_OOP.Model
{
    public class Customer: NotifyPropertyChanged
    {
        private string? _id;
        private string? _name;
        private string? _contactNumber;
        public string? Id 
        { 
            get { return _id; }
            set 
            { 
                _id = value;
                OnPropertyChanged(nameof(Id));
            }
        } 
        public string? Name 
        { 
            get { return _name; }
            set 
            { 
                _name = value;
                OnPropertyChanged(nameof(Name));
            }
        }
        public string? ContactNumber 
        { 
            get { return _contactNumber; }
            set 
            { 
                _contactNumber = value;
                OnPropertyChanged(nameof(ContactNumber));
            }
        }

        public string GenerateID()
        {
            Random random = new Random();
            string id = "";
            for (int i = 0; i < 10; i++)
            {
                int generate = random.Next(0, 9);
                id += generate;
            }
            return id;
        }
        public Customer(string name, string contactNumber)
        {
            Id = GenerateID();
            Name = name;
            ContactNumber = contactNumber;
        }
    }
}
