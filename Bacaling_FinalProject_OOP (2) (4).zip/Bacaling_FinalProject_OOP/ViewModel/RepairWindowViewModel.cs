﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Bacaling_FinalProject_OOP.Command;
using Bacaling_FinalProject_OOP.View;
using Bacaling_FinalProject_OOP.Model;

namespace Bacaling_FinalProject_OOP.ViewModel
{
    public class RepairWindowViewModel:NotifyPropertyChanged
    {
        public RepairTicket SelectedRepairTicket { get; set; }
        public ObservableCollection<RepairTicket> TicketList { get; set; } = new ObservableCollection<RepairTicket>();
        public ICommand AddTicketCommand { get; set; }
        public ICommand CancelCommand { get; set; }
        public ICommand EditStatusCommand { get; set; }
        public RepairWindowViewModel()
        {
            TicketList = RepairTicketManagementSystem.GetTickets();
            AddTicketCommand = new RelayCommand(AddTicket, CanAddTicket);
            CancelCommand = new RelayCommand(Cancel, CanCancel);
            EditStatusCommand = new RelayCommand(EditStatus, CanEditStatus);
        }

        private bool CanEditStatus(object obj)
        {
            return true;
        }

        private void EditStatus(object obj)
        {
            if(SelectedRepairTicket != null)
            {
                EditStatusWindow editStatusWindow = new EditStatusWindow();
                editStatusWindow.DataContext = new EditStatusViewModel(SelectedRepairTicket);
                editStatusWindow.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                editStatusWindow.Show();
            }
            else
            {
                string message = "Select a ticket first";
                string caption = "Error";
                MessageBoxButton button = MessageBoxButton.OK;
                MessageBoxResult boxOption = MessageBoxResult.OK;
                MessageBoxImage image = MessageBoxImage.Error;
                MessageBox.Show(message, caption, button, image);
            }
        }

        private bool CanAddTicket(object obj)
        {
            return true;
        }

        private void AddTicket(object obj)
        {
            AddRepairTicketWindow addRepairTicketWindow = new AddRepairTicketWindow();
            addRepairTicketWindow.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            addRepairTicketWindow.Show();
        }

        private bool CanCancel(object obj)
        {
            return true;
        }

        private void Cancel(object obj)
        {
            var repairWindow = obj as Window;
            repairWindow.Close();
        }
    }
}
