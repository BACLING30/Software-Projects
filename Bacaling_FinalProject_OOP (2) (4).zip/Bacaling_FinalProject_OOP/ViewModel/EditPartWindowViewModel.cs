﻿using Bacaling_FinalProject_OOP.Command;
using Bacaling_FinalProject_OOP.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows;
using System.Collections.ObjectModel;

namespace Bacaling_FinalProject_OOP.ViewModel
{
    public class EditPartWindowViewModel: NotifyPropertyChanged
    {
        public ICommand SaveChangesCommand { get; set; }
        public ICommand CancelCommand { get; set; }
        private PcComponent? _selectedPart;
        private string? _newName;
        private string? _newBrand;
        private string? _newModel;
        private string? _newId;
        private int _newPrice;
        private Category? _newCategory;
        private int? _newQuantity;

        public List<Category> CatEnum { get; set; } = new List<Category>() 
        { 
            Category.RAM, Category.CPU, Category.GPU, Category.PSU, Category.SSD, Category.MotherBoard
        }; 
        public PcComponent? SelectedPart
        {
            get { return _selectedPart; }
            set
            {
                _selectedPart = value;
                OnPropertyChanged(nameof(SelectedPart));
            }
        }
        public string? NewName
        {
            get { return _newName; }
            set
            {
                _newName = value;
                OnPropertyChanged(nameof(NewName));
            }
        }
        public string? NewBrand
        {
            get { return _newBrand; }
            set
            {
                _newBrand = value;
                OnPropertyChanged(nameof(NewBrand));
            }
        }
        public string? NewModel 
        { 
            get { return _newModel; }
            set
            {
                _newModel = value;
                OnPropertyChanged(nameof(NewModel));
            }
        }
        public string? NewId 
        { 
            get { return _newId; }
            set
            {
                _newId = value;
                OnPropertyChanged(nameof(NewId));
            }
        }
        public int NewPrice 
        { 
            get { return _newPrice; }
            set
            {
                _newPrice = value;
                OnPropertyChanged(nameof(NewPrice));
            }
        }
        public Category? NewCategory 
        { 
            get { return _newCategory; }
            set
            {
                _newCategory = value;
                OnPropertyChanged(nameof(NewCategory));
            }
        }
        public int? NewQuantity
        {
            get { return _newQuantity; }
            set 
            { 
                _newQuantity = value;
                OnPropertyChanged(nameof(NewQuantity));
            }
        }


        public EditPartWindowViewModel(PcComponent com)
        {
            NewBrand = com.Brand;
            NewName = com.Name;
            NewModel = com.Model;
            NewId= com.Id;
            NewPrice = com.Price;
            NewCategory = com.Category;
            NewQuantity = com.Quantity;
            SelectedPart = com;
            SaveChangesCommand = new RelayCommand(SaveChanges, CanSaveChanges);
            CancelCommand = new RelayCommand(Cancel, CanCancel);
        }

        private bool CanCancel(object obj)
        {
            return true;
        }

        private void Cancel(object obj)
        {
            Window editUser = obj as Window;
            editUser.Close();
        }

        private bool CanSaveChanges(object obj)
        {
            return true;
        }

        private void SaveChanges(object obj)
        {
            if (NewQuantity > 0)
            {
                PCComponentManagement.EditPart(SelectedPart, NewName, NewBrand, NewModel, NewId, NewPrice, NewCategory, NewQuantity);
                Window editCustomer = obj as Window;
                editCustomer.Close();
            }
            else
            {
                string message = "Invalid quantity";
                string caption = "Error";
                MessageBoxButton button = MessageBoxButton.OK;
                MessageBoxResult boxOption = MessageBoxResult.OK;
                MessageBoxImage image = MessageBoxImage.Error;
                MessageBox.Show(message, caption, button, image);
            }
        }
    }
}
