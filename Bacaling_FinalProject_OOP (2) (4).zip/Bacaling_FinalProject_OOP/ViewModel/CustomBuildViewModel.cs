﻿using Bacaling_FinalProject_OOP.Command;
using Bacaling_FinalProject_OOP.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection.Emit;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace Bacaling_FinalProject_OOP.ViewModel
{
    public class CustomBuildViewModel: NotifyPropertyChanged
    {
        public ObservableCollection<PcComponent> Components { get; set; } 
        public static ObservableCollection<PcComponent> PcBuilds { get; set; } = new ObservableCollection<PcComponent>();
        public ObservableCollection<PcComponent> InventoryList { get; set; }
        public ICommand AddComponentCommand { get; set; }
        public ICommand CancelCommand { get; set; }
        public ICommand DoneCommand { get; set; }
        public ICommand RemovePartCommand { get; set; }
        public ICommand ClearCommand { get; set; }
        public PcComponent Part { get; set; }
        public PcComponent Parts { get; set; }

        private int _totalPrice = 0;
        public int TotalPrice 
        {
            get { return _totalPrice; }
            set 
            {
                _totalPrice = value;
                OnPropertyChanged(nameof(TotalPrice));
            }
        }
        public CustomBuildViewModel()
        {
            Components = new ObservableCollection<PcComponent>();
            InventoryList = PCComponentManagement.GetComponents();
            AddComponentCommand = new RelayCommand(AddComponent,CanAddComponent);
            CancelCommand = new RelayCommand(Cancel,CanCancel);
            DoneCommand = new RelayCommand(Done, CanDone);
            RemovePartCommand = new RelayCommand(Remove, CanRemove);
            ClearCommand = new RelayCommand(Clear, CanClear);
        }
        public static ObservableCollection<PcComponent> GetComponents()
        {
            return PcBuilds;
        }
        private bool CanClear(object obj)
        {
            return true;
        }

        private void Clear(object obj)
        {
            foreach(PcComponent com in Components)
            {
                if(InventoryList.Contains(com))
                {
                    com.Quantity++;
                    com.SecondQuantity--;
                }
                else
                {
                    com.Quantity++;
                    com.SecondQuantity--;
                    InventoryList.Add(com);
                }
            }
            Components.Clear();
            TotalPrice = 0;
        }

        private bool CanAddComponent(object obj)
        {
            return true;
        }

        private void AddComponent(object obj)
        {
            if (Part != null)
            {
                if (Part.SecondQuantity < 1 && CategoryMatcher())
                {
                    Components.Add(Part);
                    CalculateTotal();
                    // Tracking Quantity
                    Part.Quantity--;
                    Part.SecondQuantity++;
                }
                if (Part.Quantity == 0)
                {
                    InventoryList.Remove(Part);
                }
            }
            else
            {
                string message = "Select a part first";
                string caption = "Error";
                MessageBoxButton button = MessageBoxButton.OK;
                MessageBoxResult boxOption = MessageBoxResult.OK;
                MessageBoxImage image = MessageBoxImage.Error;
                MessageBox.Show(message, caption, button, image);
            }
        }
        private bool CanRemove(object obj)
        {
            return true;
        }

        private void Remove(object obj)
        {
            if(Parts != null)
            {
                Parts.Quantity++;
                Parts.SecondQuantity--;
                TotalPrice -= Parts.Price;
                if (!InventoryList.Contains(Parts))
                {
                    InventoryList.Add(Parts);
                    Parts.Quantity = Parts.SecondQuantity + 1;
                }
                Components.Remove(Parts);
            }

        }

        public void CalculateTotal()
        {
            TotalPrice = 0;
            foreach(PcComponent com in Components)
            {
                TotalPrice += com.Price;
            }
        }
        
        private bool CanDone(object obj)
        {
            return true;
        }
       
        private void Done(object obj)
        {
            
            Window customBuild = obj as Window;
            foreach (PcComponent i in Components)
            {
                PcBuilds.Add(i);
                i.SecondQuantity = 0;
            };
            ObservableCollection<PcComponent> Fbuilds = [.. Components];// Passes the pc component list to a new list created
            string Id = GenerateID();
            PcBuild FutureBuildReference = new PcBuild(Id ,Fbuilds);
            PcBuildsManager.AddPcBuild(FutureBuildReference);
            customBuild.Close();
            Components.Clear();
        }
         public string GenerateID()
        {
            Random random = new Random();
            string id = "";
            for(int i = 0; i < 10; i++)
            {
                int generate = random.Next(0, 9);
                id += generate;
            }
            return id;
        }
        private bool CanCancel(object obj)
        {
            return true;
        }

        private void Cancel(object obj)
        {
            foreach(PcComponent com in Components)
            {
                com.Quantity++;
                com.SecondQuantity--;
            }
            Components.Clear();
            Window? customBuildWindow = obj as Window;
            customBuildWindow.Close();
        }
        
        private bool CategoryMatcher() //Checks whether PC build already has that part if it already has that part then it will not allow any of the same category to be added to the current build
        {
            foreach (PcComponent com in Components)
            {
                if (Part.Category == com.Category)
                {
                    return false;
                }
            }
            return true;
        }
    }
}
