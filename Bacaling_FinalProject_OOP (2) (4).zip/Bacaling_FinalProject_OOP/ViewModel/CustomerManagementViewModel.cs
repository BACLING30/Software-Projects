﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Security.RightsManagement;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Bacaling_FinalProject_OOP.Command;
using Bacaling_FinalProject_OOP.Model;
using Bacaling_FinalProject_OOP.View;

namespace Bacaling_FinalProject_OOP.ViewModel
{
    public class CustomerManagementViewModel: NotifyPropertyChanged
    {
        public ObservableCollection<Customer> Customers { get; set; }
        public ICommand EditUserCommand { get; set; }
        public ICommand ReturnCommand { get; set; }
        public ICommand AddUserCommand { get; set; }
        public ICommand RemoveUserCommand { get; set; }

        private Customer _selectedCustomer;

        public Customer SelectedCustomer
        {
            get { return _selectedCustomer; }
            set 
            { 
                _selectedCustomer = value;
                OnPropertyChanged(nameof(SelectedCustomer));
            }
        }
        public CustomerManagementViewModel()
        {
            Customers = CustomerManagementSystem.GetCustomers();
            ReturnCommand = new RelayCommand(Return, CanReturn);
            AddUserCommand = new RelayCommand(AddUser, CanAddUser);
            RemoveUserCommand = new RelayCommand(RemoveUser, CanRemoveUser);
            EditUserCommand = new RelayCommand(EditUser, CanEditUser);
        }

        private bool CanEditUser(object obj)
        {
           return true;
        }

        private void EditUser(object obj)
        {
            if(SelectedCustomer != null)
            {
                EditCustomerWindow editCustomer = new EditCustomerWindow();
                editCustomer.DataContext = new EditCustomerViewModel(SelectedCustomer);
                editCustomer.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                editCustomer.Show();
            }
        }

        private bool CanRemoveUser(object obj)
        {
            return true;
        }

        private void RemoveUser(object obj)
        {
            CustomerManagementSystem.RemoveCustomer(SelectedCustomer);
        }


        private bool CanAddUser(object obj)
        {
            return true;
        }

        private void AddUser(object obj)
        {
            AddCustomerWindow add = new AddCustomerWindow();
            add.WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;
            add.Show();
        }

        private bool CanReturn(object obj)
        {
            return true;
        }

        private void Return(object obj)
        {
            Window? customerManagementWindow = obj as Window;
            customerManagementWindow.Close();
        }
    }
}
