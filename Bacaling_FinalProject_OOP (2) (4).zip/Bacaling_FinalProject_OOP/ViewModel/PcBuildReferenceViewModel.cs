﻿using Bacaling_FinalProject_OOP.Command;
using Bacaling_FinalProject_OOP.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace Bacaling_FinalProject_OOP.ViewModel
{
    public class PcBuildReferenceViewModel: NotifyPropertyChanged
    {
        private PcBuild _selectedPart;
        public PcBuild SelectedPart
        {
            get { return _selectedPart; }
            set
            {
                _selectedPart = value;
                OnPropertyChanged(nameof(SelectedPart));    
            }
        }
        public static ObservableCollection<PcBuild> FutureBuildView { get; set; } = new ObservableCollection<PcBuild>();
        public ICommand CancelCommand { get; set; }
        public PcBuildReferenceViewModel()
        {
            FutureBuildView = PcBuildsManager.GetBuilds();
            CancelCommand = new RelayCommand(Cancel, CanCancel);
        }

        private bool CanCancel(object obj)
        {
            return true;
        }

        private void Cancel(object obj)
        {
            Window? referenceWindow = obj as Window;
            referenceWindow.Close();
        }
    }
}
