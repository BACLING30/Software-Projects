﻿using Bacaling_FinalProject_OOP.Command;
using Bacaling_FinalProject_OOP.Model;
using Bacaling_FinalProject_OOP.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace Bacaling_FinalProject_OOP.ViewModel
{
    public class MainViewModel: NotifyPropertyChanged
    {
        public event PropertyChangingEventHandler? PropertyChanged;
        public ICommand ShowInventoryWindowCommand { get; set; }
        public ICommand ShowRepairWindowCommand { get; set; }
        public ICommand ShowCustomerManagementCommand { get; set; }
        public ICommand ShowPastPcBuildReferenceCommand { get; set; }
        public ICommand ShowCustomBuildCommand { get; set; }
        

        public MainViewModel()
        {
            ShowInventoryWindowCommand = new RelayCommand(ShowInventoryWindow, CanShowInventoryWindow);
            ShowRepairWindowCommand = new RelayCommand(ShowRepairWindow, CanShowRepairWindowCommand);
            ShowCustomerManagementCommand = new RelayCommand(ShowCustomerManagement, CanShowCustomerManagement);
            ShowCustomBuildCommand = new RelayCommand(ShowCustomBuild, CanShowCustomBuild);
            ShowPastPcBuildReferenceCommand = new RelayCommand(ShowPastPcBuildReference, CanShowPastPcBuildReference);
        }

        private bool CanShowPastPcBuildReference(object obj)
        {
            return true;
        }

        private void ShowPastPcBuildReference(object obj)
        {
            PcBuildReferenceWindow pcBuildReference = new PcBuildReferenceWindow();
            pcBuildReference.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            pcBuildReference.Show();
        }

        private bool CanShowCustomBuild(object obj)
        {
            return true;
        }

        private void ShowCustomBuild(object obj)
        {
            CustomBuild customBuild = new CustomBuild();
            customBuild.WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;
            customBuild.Show();
        }

        private bool CanShowCustomerManagement(object obj)
        {
            return true;
        }

        private void ShowCustomerManagement(object obj)
        {
            CustomerManagement customerManagement = new CustomerManagement();
            customerManagement.WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;
            customerManagement.Show();
        }

        private bool CanShowInventoryWindow(object obj)
        {
            return true;
        }

        private void ShowInventoryWindow(object obj)
        {
            InventoryWindow inventoryWindow = new InventoryWindow();
            inventoryWindow.WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;
            inventoryWindow.Show();
        }
        private bool CanShowRepairWindowCommand(object obj)
        {
            return true;        
        }
        private void ShowRepairWindow(object obj)
        {
            RepairWindow repairWindow = new RepairWindow();
            repairWindow.WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;
            repairWindow.Show();
        }
        
    }
}
