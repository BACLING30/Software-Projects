﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bacaling_FinalProject_OOP.ViewModel;
using Bacaling_FinalProject_OOP.Model;
using Bacaling_FinalProject_OOP.Command;
using System.Windows.Input;
using System.Windows;
using System.Collections.ObjectModel;

namespace Bacaling_FinalProject_OOP.ViewModel
{
    public class AddRepairWindowTicketViewModel: NotifyPropertyChanged
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string ContactNumber { get; set; }
        public Customer Customers { get; set; }
        public string Describe { get; set; }

        private Diagnosis _diagnose;
        public Diagnosis Diagnose 
        {
            get { return _diagnose; }
            set 
            { 
                _diagnose = value;
                KnowPrice();
            }
        }
        public ObservableCollection<Diagnosis> DiagnosisList { get; set; } = new ObservableCollection<Diagnosis>() 
        { 
            Diagnosis.Hardware, Diagnosis.Software
        };
        private double _repCost = 4000;
        public double RepCost 
        {
            get { return _repCost; }
            set 
            {  
                _repCost = value;
                OnPropertyChanged(nameof(RepCost));
            }
        }
        public Status Stat { get; set; }
        public ObservableCollection<Status> StatusList { get; set; } = new ObservableCollection<Status>()
        { Status.Completed, Status.Ongoing, Status.Open };
        public RepairTicket Ticket { get; set; }
        public ObservableCollection<RepairTicket> RepairTicketList { get; set; } = new ObservableCollection<RepairTicket>();
        public ICommand AddTicketCommand { get; set; }
        public ICommand CancelCommand { get; set; }

        public AddRepairWindowTicketViewModel()
        {
            RepairTicketList = RepairTicketManagementSystem.GetTickets();
            AddTicketCommand = new RelayCommand(AddTicket, CanAddTicket);
            CancelCommand = new RelayCommand(Cancel, CanCancel);
        }

        private bool CanCancel(object obj)
        {
            return true;
        }

        private void Cancel(object obj)
        {
            Window addRepairTicketWindow = obj as Window;
            addRepairTicketWindow.Close();
        }

        private bool CanAddTicket(object obj)
        {
            return true;
        }

        private void AddTicket(object obj)
        {
            Customer customer = new Customer(Name, ContactNumber);
            RepairTicket rep = new RepairTicket(customer, Describe, Diagnose, Stat);
            CustomerManagementSystem.AddCustomer(customer);
            RepairTicketManagementSystem.AddTicket(rep);
            Window add = obj as Window;
            add.Close();
        }
        private void KnowPrice()
        {
            if(Diagnose == Diagnosis.Hardware)
            {
                RepCost = 4000;
            }
            else
            {
                RepCost = 1000;
            }
        }
    }
}
