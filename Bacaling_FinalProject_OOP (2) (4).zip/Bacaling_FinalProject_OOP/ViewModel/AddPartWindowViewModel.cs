﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Bacaling_FinalProject_OOP.Command;
using Bacaling_FinalProject_OOP.Model;

namespace Bacaling_FinalProject_OOP.ViewModel
{
    public class AddPartWindowViewModel: NotifyPropertyChanged
    {
        private string _id;
        private string _name;
        private string _brand;
        private string _model;
        private int _price;
        private Category _category;
        private int _quantity;
        public List<Category> CategoryEnum { get; set; } = new List<Category>() 
        { 
           Category.CPU,Category.GPU,Category.RAM, Category.PSU, Category.SSD, Category.MotherBoard
        };
        public string Id
        {
            get { return _id; }
            set { _id = value; }
        }

        public string Name
        {
            get { return _name; }
            set{ _name = value; }
        }
        public string Brand
        {
            get { return _brand; }
            set{ _brand = value; }
        }
        public string Model
        {
            get { return _model; }
            set{ _model = value; }
        } 
        public int Price
        {
            get { return _price; }
            set{ _price = value; }
        }

        public Category Category
        {
            get { return _category; }
            set 
            { 
                _category = value;
                OnPropertyChanged(nameof(Category));
            }
        }
        public int Quantity
        {
            get { return _quantity; }
            set 
            { 
                _quantity = value;
                OnPropertyChanged(nameof(Quantity));
            }
        }
        public ICommand AddPartCommand { get; set; }
        public ICommand CancelCommand { get; set; }
        public AddPartWindowViewModel()
        {
            AddPartCommand = new RelayCommand(AddPart, CanAddPart);
            CancelCommand = new RelayCommand(Cancel, CanCancel);
        }

        private bool CanCancel(object obj)
        {
            return true;
        }

        private void Cancel(object obj)
        {
            var addPartWindow = obj as Window;
            addPartWindow.Close();
        }

        private bool CanAddPart(object obj)
        {
            return true;
        }

        private void AddPart(object obj)
        {
            if(Quantity > 0)
            {
                PcComponent addPart = new PcComponent(Id, Name, Brand, Model, Price, Category, Quantity);
                PCComponentManagement.AddPart(addPart);
                var addPartWindow = obj as Window;
                addPartWindow.Close();
            }
            else
            {
                string message = "Cannot have 0 quantity";
                string caption = "Error";
                MessageBoxButton button = MessageBoxButton.OK;
                MessageBoxResult boxOption = MessageBoxResult.OK;
                MessageBoxImage image = MessageBoxImage.Error;
                MessageBox.Show(message, caption, button, image);
            }
            
        }
    }
}
