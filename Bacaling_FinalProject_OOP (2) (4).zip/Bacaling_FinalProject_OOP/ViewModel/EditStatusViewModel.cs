﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Bacaling_FinalProject_OOP.Command;
using Bacaling_FinalProject_OOP.Model;

namespace Bacaling_FinalProject_OOP.ViewModel
{
    public class EditStatusViewModel: NotifyPropertyChanged
    {
        public Customer Person { get; set; }
        public string? NewName { get; set; }
        public Diagnosis? RepairDiagnosis { get; set; }
        public RepairTicket SelectedTicket { get; set; }
        public ICommand SaveStatusCommand { get; set; }
        public ICommand CancelCommand { get; set; }
        private Status? _newStatus;
        public Status? NewStatus
        {
            get { return _newStatus; }
            set 
            { 
                _newStatus = value;
                OnPropertyChanged(nameof(NewStatus));
            }
        }
        public ObservableCollection<Status> Statuses { get; set; } = new ObservableCollection<Status>() 
        { 
            Status.Completed, Status.Ongoing, Status.Open
        };
        public EditStatusViewModel(RepairTicket rep)
        {
            SelectedTicket = rep;
            NewStatus = rep.Status;
            NewName = rep.Customer.Name;
            RepairDiagnosis = rep.Diagnosis;
            SaveStatusCommand = new RelayCommand(SaveStatus, CanSaveStatus);
            CancelCommand = new RelayCommand(Cancel, CanCancel);
        }

        private bool CanCancel(object obj)
        {
            return true;
        }

        private void Cancel(object obj)
        {
            Window editStatus = obj as Window;
            editStatus.Close();
        }

        private bool CanSaveStatus(object obj)
        {
            return true;
        }

        private void SaveStatus(object obj)
        {
            RepairTicketManagementSystem.EditStatus(SelectedTicket, NewStatus);
            Window editStatus = obj as Window;
            editStatus.Close();
        }
    }
}
