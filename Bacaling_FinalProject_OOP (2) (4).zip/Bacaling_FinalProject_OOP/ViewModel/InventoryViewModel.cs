﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Bacaling_FinalProject_OOP.Command;
using Bacaling_FinalProject_OOP.Model;
using Bacaling_FinalProject_OOP.View;

namespace Bacaling_FinalProject_OOP.ViewModel
{
    public class InventoryViewModel: NotifyPropertyChanged
    {
        public PcComponent PcParts { get; set; }
        public ObservableCollection<PcComponent> Component { get; set; }
        public ICommand CancelCommand { get; set; }
        public ICommand AddPartCommand { get; set; }
        public ICommand RemovePartCommand { get; set; }
        public ICommand EditPartCommand { get; set; }

        public List<Category> Categories { get; set; } = new List<Category>()
        {
           Category.CPU,Category.GPU,Category.RAM,Category.PSU,Category.SSD
        };
        public InventoryViewModel()
        {
            Component = PCComponentManagement.GetComponents();
            CancelCommand = new RelayCommand(Cancel, CanCancel);
            AddPartCommand = new RelayCommand(AddPart, CanAddPart);
            RemovePartCommand = new RelayCommand(RemovePart, CanRemovePart);
            EditPartCommand = new RelayCommand(EditPart, CanEditPart);
        }

        private bool CanEditPart(object obj)
        {
            return true;
        }

        private void EditPart(object obj)
        {
            if(PcParts != null)
            {
                EditPartWindow editPart = new EditPartWindow();
                EditPartWindowViewModel editor = new EditPartWindowViewModel(PcParts);
                editPart.DataContext = editor;
                editPart.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                editPart.Show();
            }
        }

        private bool CanRemovePart(object obj)
        {
            return true;
        }

        private void RemovePart(object obj)
        {
            PCComponentManagement.RemovePart(PcParts);
        }

        private bool CanAddPart(object obj)
        {
            return true;
        }

        private void AddPart(object obj)
        {
            AddPartWindow addPart = new AddPartWindow();
            addPart.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            addPart.Show();
        }

        private bool CanCancel(object obj)
        {
            return true;
        }

        private void Cancel(object obj)
        {
            Window repairWindow = obj as Window;
            repairWindow.Close();
        }
    }
}
