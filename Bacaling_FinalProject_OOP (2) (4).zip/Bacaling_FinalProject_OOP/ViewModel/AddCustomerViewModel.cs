﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Bacaling_FinalProject_OOP.Command;
using Bacaling_FinalProject_OOP.Model;

namespace Bacaling_FinalProject_OOP.ViewModel
{
    public class AddCustomerViewModel: NotifyPropertyChanged
    {
        private string _id;
        private string _name;
        private string _contactNumber;
        public ICommand AddCustomerCommand { get; set; }
        public ICommand CancelCommand { get; set; }

        public string Id
        {
            get { return _id; }
            set { _id = value;}
        }
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public string ContactNumber
        {
            get { return _contactNumber; }
            set { _contactNumber = value; }
        }
        
        public AddCustomerViewModel()
        {
            AddCustomerCommand = new RelayCommand(AddCustomer, CanAddCustomer);
            CancelCommand = new RelayCommand(Cancel, CanCancel);
        }

        private bool CanCancel(object obj)
        {
           return true;
        }

        private void Cancel(object obj)
        {
            var addCustomer = obj as Window;
            addCustomer.Close();
        }

        private bool CanAddCustomer(object obj)
        {
            return true;
        }

        private void AddCustomer(object obj)
        {
            Customer cus = new Customer(Name, ContactNumber);
            CustomerManagementSystem.AddCustomer(cus);
            var addUserWindow = obj as Window;
            addUserWindow.Close();
        }
    }
}
