﻿using Bacaling_FinalProject_OOP.Command;
using Bacaling_FinalProject_OOP.Model;
using Bacaling_FinalProject_OOP.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace Bacaling_FinalProject_OOP.ViewModel
{
    public class EditCustomerViewModel: NotifyPropertyChanged
    {
        public ICommand SaveChangesCommand { get; set; }
        public ICommand CancelCommand { get; set; }
        private Customer _selectedCustomer;
        private string? _newId;
        private string? _newName;
        private string? _newContactNumber;
        public Customer SelectedCustomer
        {
            get { return _selectedCustomer; }
            set 
            { 
                _selectedCustomer = value;
                OnPropertyChanged(nameof(SelectedCustomer));
            }
        }
        public string? NewId
        {
            get { return _newId; }
            set 
            { 
                _newId = value; 
                OnPropertyChanged(nameof(NewId));
            }
        }
        public string? NewName
        {
            get { return _newName; }
            set 
            { 
                _newName = value; 
                OnPropertyChanged(nameof(NewName));
            }
        }
        public string? NewContactNumber
        {
            get { return _newContactNumber; }
            set 
            { 
                _newContactNumber = value; 
                OnPropertyChanged(nameof(NewContactNumber));
            }
        }

        public EditCustomerViewModel(Customer cus)
        {
            if(SelectedCustomer != null)
            {
                NewId = cus.Id;
                NewName = cus.Name;
                NewContactNumber = cus.ContactNumber;
                SelectedCustomer = cus;
                SaveChangesCommand = new RelayCommand(SaveChanges, CanSaveChanges);
                CancelCommand = new RelayCommand(Cancel, CanCancel);
            }
        }

        private bool CanCancel(object obj)
        {
            return true;
        }

        private void Cancel(object obj)
        {
            Window? editUser = obj as Window;
            editUser.Close();
        }

        private bool CanSaveChanges(object obj)
        {
            return true;
        }

        private void SaveChanges(object obj)
        {
            CustomerManagementSystem.EditCustomer(SelectedCustomer, NewId, NewName, NewContactNumber);
            Window? editCustomer = obj as Window;
            editCustomer.Close();
        }
    }
}
